fx_version 'cerulean'
game 'gta5'

author 'matza'
description 'Sabit NPC Scripti'
version '1.0'

client_script 'client.lua'
