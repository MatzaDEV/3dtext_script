local displayText = "[E] Menu" -- Gösterilecek metin
local textCoords = vector3(-32.87, -1097.67, 26.42) -- Metnin gösterileceği konum
local displayDistance = 15.0 -- Metnin görülebileceği mesafe

-- 3D metin çizme fonksiyonu
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())

    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)

        local factor = (string.len(text)) / 370
        DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 75)
    end
end


-- Oyuncunun belirlenen konuma yakın olup olmadığını kontrol eden döngü
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        if #(playerCoords - textCoords) < displayDistance then
            DrawText3D(textCoords.x, textCoords.y, textCoords.z, displayText)
        end
    end
end)
